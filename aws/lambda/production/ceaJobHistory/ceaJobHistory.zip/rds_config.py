#config file containing credentials for rds mysql instance
db_endpoint = "cea.cjbv7rlz4hsg.us-east-1.rds.amazonaws.com"
db_username = "root"
db_password = "7#&KV88%o3%9i"
db_name = "cea"
